import firebase from './firebase';
import FirebaseContext from '../firebase/context';

export { FirebaseContext }

export default  firebase;
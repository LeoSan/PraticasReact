const  firebaseConfig = {
    apiKey: "AIzaSyCAuuua21ag1_RH-YHn83M8AaVxA09nn6c",
    authDomain: "proyectonextreact.firebaseapp.com",
    databaseURL: "https://proyectonextreact.firebaseio.com",
    projectId: "proyectonextreact",
    storageBucket: "proyectonextreact.appspot.com",
    messagingSenderId: "74032161921",
    appId: "1:74032161921:web:542c6bd602474cea265980"
  };

  export default firebaseConfig; 
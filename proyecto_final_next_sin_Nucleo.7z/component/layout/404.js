import React from 'react';

const Error404 = ({mensaje}) => {
return ( <h1 className="Error404">{mensaje}</h1> );
}
 
export default Error404;
